NetId - adporwal
SpringBoot WebaApp - Bookstore
Port : 8080
DB : SQL with JPA
DB Confuguration : application.properties
DB Schema + Dummy Data : bookstore.sql

Please execute the queries provided in the bookstore.sql file to create the schema and insert the dummy data before running the application.