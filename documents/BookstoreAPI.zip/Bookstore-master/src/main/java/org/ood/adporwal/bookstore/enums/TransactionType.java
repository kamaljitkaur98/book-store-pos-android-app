package org.ood.adporwal.bookstore.enums;

public enum TransactionType {
    PURCHASE,
    SELL,
    BUYBACK
}

